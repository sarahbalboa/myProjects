#!/bin/sh
#_____________________________________________________________
#			_AUTHOR INFO_			      |
#	Name: SARA HUSSEIN CELDA			      |
#	Matric num: 40496531				      |
#	Course/Module: Software Engineering/Operating Systems |
#_____________________________________________________________|
#Start of script

#___________________________________CREATE DOCKERS______________________________
echo "Creating Docker containers..."

#file where the txt files will be stored
mkdir files

#create all the dockers and copy the empty file 'files' on them.
#-d, --detach    Run container in background and print container ID (information source --> man command)

sudo docker run -itd --name docker1 ubuntu /bin/sh > /dev/null
sudo docker cp ~/files docker1:/
echo "Docker 1 created..."

sudo docker run -itd --name docker2 ubuntu /bin/sh > /dev/null
sudo docker cp ~/files docker2:/
echo "Docker 2 created..."

sudo docker run -itd --name docker3 ubuntu /bin/sh > /dev/null
sudo docker cp ~/files docker3:/
echo "Docker 3 created..."

#___________________________COPY FILES IN THE DOCKER CONTAINERS________________

#______________copy the txt files from Dockers1 and sort by size (small-big) inside the docker container___________________________
filelist=($(ls ./'Docker Files'/Docker1)) #file list with all the files in the Docker Files folder

#As a filelist cannot be used as part of a path  when copying the txt files
#from Docker1 folder, we need to create an array with all the files names.
index=0
array_length=${#filelist[@]} #number of files
while [ $index -lt $array_length ]
do
  d1[$index]=${filelist[$index]} #array with all the elements in the filelist
  #copy in the docker container all the files.
  sudo docker cp ./'Docker Files'/Docker1/${d1[$index]} docker1:/files/${d1[$index]}
  index=`expr $index + 1`
done
                #__________________________________________________________

#now we create another file list with the files ordered by size (-Sr) in number of characters reversed (small-large)
#and we rename them due to this order.
filelist=($(sudo docker exec --workdir /files docker1 ls -Sr))
index=0
array_length=${#filelist[@]} #number of files
while [ $index -lt $array_length ]
do
  #we use the --workdir to specify the workdirectory in the docker where te command will be executed.
  sudo docker exec --workdir /files docker1 mv ${filelist[$index]} $index.txt
  index=`expr $index + 1`
done

echo "Loaded files to Docker 1..."

#_______________Copy files without changes from Docker2_________________________________
filelist=($(ls ./'Docker Files'/Docker2))
array_length=${#filelist[@]}
index=0
while [ $index -lt $array_length ]
do
  d2[$index]=${filelist[$index]}
  sudo docker cp ./'Docker Files'/Docker2/${d2[$index]} docker2:/files/$index.txt
  index=`expr $index + 1`
done
echo "Loaded files to Docker 2..."

#_____________copy files from Docker3 by size (small-big)___________________________
#we do the same as with docker1
filelist=($(ls ./'Docker Files'/Docker3)) 

index=0
array_length=${#filelist[@]}
while [ $index -lt $array_length ]
do
  d3[$index]=${filelist[$index]}
    sudo docker cp ./'Docker Files'/Docker3/${d3[$index]} docker3:/files/${d3[$index]}
  index=`expr $index + 1`
done

                #_______________________________________________

filelist=($(sudo docker exec --workdir /files docker3 ls -Sr))
index=0
array_length=${#filelist[@]}

while [ $index -lt $array_length ]
do
  
  sudo docker exec --workdir /files docker3 mv ${filelist[$index]} $index.txt
  index=`expr $index + 1`
done

echo "Loaded files to Docker 3..."

echo "beginning text creation GAME_OF_DOCKERS.txt..."

#_______________________________CREATION OF GAME_OF_DOCKERS____________________
#array with the name of the files
  file_num[0]="0.txt"
  file_num[1]="1.txt"
  file_num[2]="2.txt"
  file_num[3]="3.txt"
  file_num[4]="4.txt"
  file_num[5]="5.txt"
  file_num[6]="6.txt"
  file_num[7]="7.txt"

#the files will be copied in pairs, these variables represent file1 and file2 in each round of the loop
VAR_file=0
VAR_file2=1
array_length=${#file_num[@]}
loop_length=`expr $array_length + 1`
#this loop will use the files in pairs, for instance: 0-1, 2-3, 4-5... And it will create the-
#GAME_OF_DOCKERS.txt in the root directory of the user.
#Plus we have 2 if-statement to copy the files depending on the number of files that the Docker has

#Docker1 has : 0.txt 1.txt 2.txt 3.txt 4.txt
#Docker2 has : 0.txt 1.txt 2.txt 3.txt 4.txt 5.txt
#Docker3 has : 0.txt 1.txt 2.txt 3.txt 4.txt 5.txt 6.txt 7.txt

while [ $VAR_file2 -lt $loop_length ]
do
  #Docker3
  if [ $VAR_file -eq 6 ] #when we reach file 6 we just copy files from Docker3 as it is the only one that has file 6 and 7 (it has files 0,1,2,3,4,5,6,7)
  	then
	#you can specify an order director where the command will by executed in a Docker with (exec -w) modifier
  	sudo docker exec -w /files docker3 cat ${file_num[$VAR_file]} ${file_num[$VAR_file2]} >> ./GAME_OF_DOCKERS.txt #append files form docker in the GAME_OF_DOCKERS.txt 
  	echo -e "\n" >> ./GAME_OF_DOCKERS.txt #this is just for aesthetic...
  	echo "Loading files $VAR_file and $VAR_file2 from 3rd Docker container..."
  else
	  #Docker1
	  if [ $VAR_file -eq 4 ] #This if-statement is just for Docker1. When 4 is reached, just use the file 4 as there is no file 5 in the Docker1.
	  then
	    sudo docker exec -w /files docker1 cat ${file_num[$VAR_file]} >> ./GAME_OF_DOCKERS.txt
	    echo -e "\n" >> ./GAME_OF_DOCKERS.txt
	    echo "Loading file $VAR_file th from 1st Docker container..."
	  else #whe haven't reached yet the couple 4-5 of files
	    sudo docker exec -w /files docker1 cat ${file_num[$VAR_file]} ${file_num[$VAR_file2]} >> GAME_OF_DOCKERS.txt 
	    echo -e "\n" >> ./GAME_OF_DOCKERS.txt
	    echo "Loading files $VAR_file and $VAR_file2 from 1st Docker container..."
	  fi

      	  #Docker2
	  sudo docker exec -w /files docker2 cat ${file_num[$VAR_file]} ${file_num[$VAR_file2]} >> ./GAME_OF_DOCKERS.txt 
	  echo -e "\n" >> ./GAME_OF_DOCKERS.txt
	  echo "Loading files $VAR_file and $VAR_file2 from 2nd Docker container..."

	  #Docker3
	  sudo docker exec -w /files docker3 cat ${file_num[$VAR_file]} ${file_num[$VAR_file2]} >> ./GAME_OF_DOCKERS.txt 
	  echo -e "\n" >> ./GAME_OF_DOCKERS.txt
	  echo "Loading files $VAR_file and $VAR_file2 from 3rd Docker container..."
  fi
  VAR_file=`expr $VAR_file + 2` #files 0,2,4,6
  VAR_file2=`expr $VAR_file2 + 2` #files 1,3,5,7
done

#_____________________Here stars the while loop for all the questions created for the user____________________________________

Var_exit=0 #flag variable to terminate the program
while [ $Var_exit -eq 0 ]
do

	#_________________________QUESTION 1 TO USER___________________________________

	VAR_flag=0
	while [ $VAR_flag = 0 ] #While loop to keep asking if an invalid answer is entered.
	do
		read -p "Would you like to read Game of Dockers? [Yes/No]: " choice
		case $choice in
		  Yes)
		     VAR_flag=1
		     echo -e "\n ___________________________________GAME_OF_DOCKERS______________________________\n"
		     cat ./GAME_OF_DOCKERS.txt
		     echo -e "__________________________________________________________________________\n"
		     ;;
		  No)
		     VAR_flag=1
		     echo "As you wish..."
		     ;;
		   *)
		     echo -e "\n**********IVALID INPUT --> ENTER [Yes/No]*************\n"
		     ;;
		esac
	done

	#_________________________QUESTION 2 TO USER__________________________________
	VAR_flag=0
	while [ $VAR_flag = 0 ] #While loop to keep asking if an invalid answer is entered.
	do
		read -p "Would you like to remove any text from Game of Dockers? [Yes/No]: " choice
			case $choice in
			Yes)
			   echo "Enter the text that you would wish to delete: "
			   read Var_input
			   # -e is used to delete a hole sentence input, not just a word
			   sed -i -e "s/$Var_input//g" ./GAME_OF_DOCKERS.txt
			   ;;
			No)
			  echo "Ok..."
		          VAR_flag=1
			  ;;
			*)
			  echo -e "\n**********IVALID INPUT --> ENTER [Yes/No]*************\n"
			  ;;
			esac
	done

	#__________________________QUESTION 3 TO USER__________________________________________

	VAR_flag=0
	while [ $VAR_flag = 0 ]
	do
		read -p "Would you like to add any text to Game of Dockers? [Yes/No]: " choice
		  case $choice in
		  Yes)
		     echo "Enter the text that you would wish to add at the end of the file: " 
		     read Var_input
		     echo $Var_input >> ./GAME_OF_DOCKERS.txt
		     ;;
		  No)
		     echo "Then it will remain as it is..."
	             VAR_flag=1
		     ;;
		  *)
		     echo -e "\n**********IVALID INPUT --> ENTER [Yes/No]*************\n"
		     ;;
		  esac
	done

	#___________________________QUESTION 4 TO USER____________________________________________
	Var_flag=0
	while [ $Var_flag -eq 0 ]
	do
		read -p "Would you like to terminate the program? [Yes/No]: " choice
		  case $choice in
		  Yes)
		     echo "Goodbye! :]"
		     exit
		     ;;
		  No)
		     echo -e "Nice let's go again! \n"
		     Var_flag=1
		     ;;
		  *)
		     echo -e "\n**************INVALID INPUT --> ENTER [Yes/No]********************\n"
		     ;;
		  esac
	done
done

#END OF SCRIPT____________
