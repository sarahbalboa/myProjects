/*
Author: Sara Hussein Celda
Date: 30/04/2021
Purpose: count how many identifiers (variables and functions) are declared in the given .c file(argv[1]).
Parameters:
    -Char **argv: takes from the command line the argument 1 which will be the file from the program reads in.
*/
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <algorithm>
#include <iterator>
#include "all_programs_header.h"
using namespace std;

void findVarFunct(char **argv)
{
    const int key_size = 13;
    ifstream file(argv[1]); //open of read in the file
    string line;//buffer for the file lines
    int identifier = 0;
    int func_variable = 0;
    int func_number = 0;
    string keyWords[key_size] = {"int", "char", "short", "long" , "double", "float","int*", "char*", "short*", "long*" , "double*", "float*"};
    vector<string> data;

    while(getline(file,line)) //while the file is not NULL
    {
        line.erase(remove(line.begin(), line.end(), '\t'),line.end());
        
        //we tokenize the array by spaces
        string s = " ";
        while(line.size())
        {
            int index = line.find(s); //index in which exist our token
            if(index!=string::npos) //if index is found
            {
                data.push_back(line.substr(0,index)); //push-back from beggining until the index of the space
                line = line.substr(index+s.size()); //substract all that has been pushed-back + token
                if(line.size()==0)data.push_back(line);
            }
            else//index not found
            {
                data.push_back(line);
                line = "";
            }
        }

        //find functions---------------------------------------------------
        for(int i = 0; i < (key_size -1); i++)
        {
            for (int j = 0; j < data.size(); j++)
            {
                if(data[j] == keyWords[i])
                {
                    j++;
                    j++;
                    if(data[j] == "(")
                    {
                        func_variable++;
                        func_number++;
                    }
                }
            }
        }
        for (int j = 0; j < data.size(); j++)
        {
            if(data[j] == "void") //functions that returns nothing
            {
                j++;
                j++;
                if(data[j] == "(")
                {
                    func_number++;
                }
            }
        }
        //find identifiers-----------------------------
        for( int i = 0; i < (key_size - 1); i++)
        {
            
            for(int j = 0; j < data.size();)
            {
                if(data[j] == keyWords[i])
                {     
                    identifier++;  
                }

                //In case of finding "long long" or "long long*" we avoid counting long twice.
                if(data[j] == "long") 
                {
                    j++;
                }
                j++;
            }
        }

        data.clear();

    }
    
    int variables = identifier - func_variable; //variables= identifiers - functions 

    
    cout<<"Variables: "<< variables <<endl;
    cout<<"Functions: "<< func_number <<endl;
    

    file.close();
    //return 0;
}