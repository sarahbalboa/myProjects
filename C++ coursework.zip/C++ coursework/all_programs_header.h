/*
Author: Sara Hussein Celda
Date: 30/04/2021
Purpose: header that contains all the symbol_table files for creating the application
*/
#pragma once 

void findVarFunct(char **argv);
void ifStatementLoop(char **argv);
void identifier_table_bst(char **argv);