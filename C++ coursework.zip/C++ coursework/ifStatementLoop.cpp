/*
Author: Sara Hussein Celda
Date: 30/04/2021
Purpose: count how many for-loops, while-loops and if-statements there are in the given .c file(argv[1]).
Parameters:
    -Char **argv: takes from the command line the argument 1 which will be the file from the program reads in.
*/
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <algorithm>
#include <iterator>
#include "all_programs_header.h"
using namespace std;


void ifStatementLoop(char **argv)
{
   
    ifstream file(argv[1]); //open of read in the file
    string line;//buffer for the file lines

    vector<string> data;
    int statement = 0;
    int for_loop = 0;
    int while_loop = 0;

    while(getline(file,line)) //while the file is not NULL
    {
        line.erase(remove(line.begin(), line.end(), '\t'),line.end());
        
        //we tokenize the array by spaces-----------------------------------------------------------------------
        string s = " ";
        while(line.size())
        {
            int index = line.find(s); //index in which exist our token
            if(index!=string::npos) //if index is found
            {
                data.push_back(line.substr(0,index)); //push-back from beggining until the index of the space
                line = line.substr(index+s.size()); //substract all that has been pushed-back + token
                if(line.size()==0)data.push_back(line);
            }
            else//index not found
            {
                data.push_back(line);
                line = "";
            }
        }

        //find if-statements/for-loops/while-loops------------------------------------------------------------------------------------
        for(int i = 0; i < data.size(); i++)
        {
            if(data[i] == "if")
            {
                i++;
                if(data[i] == "(")
                {
                    statement++;
                }
                
            }
            if(data[i] == "for")
            {
                i++;
                if(data[i] == "(")
                {
                    for_loop++;
                }
                
            }
            if(data[i] == "while")
            {
                i++;
                if(data[i] == "(")
                {
                    while_loop++;
                }
                
            }
        }
        
        data.clear();

    }

    //print all
    cout<< "If Statements: " << statement <<endl;
    cout<< "For loops: " << for_loop <<endl;
    cout<< "While loops: " << while_loop <<endl;
    
    file.close();

    //return 0;
}