/*
Author: Sara Hussein Celda
Date: 30/04/2021
Purpose:  produce an output file called identifiers.txt that contains a symbol table, which contains one row for each identifier (variable name or function name) declared in the .c file and store in a Binary 
          search tree symbol table with the identifierst information in alphabetic order.
    This identifier information consists on:
        -Identifier name
        -Line number in the file on which the identifier is declared.
        -Whether the identifier is a variable, array, or function.
        -The type of the identifier.
        -The number of times that the identifier is referenced in the file.
*/
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <iterator>
#include "all_programs_header.h"
#include "bst.h"

using namespace std;



/*---Funtion 1: writefile_buildBST---
Purpose: write in the .txt file the identifier information from the .c file and insert the lines of the identifiers information in the BST.
Parameters: 
    -String &filename = name of the file that we edit, it is declared in the main function.
    -Vector<string> &info_identifier: where the raw of the identifier information is stored
    -String &key = key to be inserted in the BST
    -BST &n = object of the BST class.
*/
void writefile_buildBST(string &filename , vector<string> &info_identifier, string &key, BST &n)
{
    //------------Create the .txt file---------------------------------------------------------------------------------
    ofstream fileOut(filename,ios::app);
    
    //for-loop 1: store all the information from info_identifier vector in the .txt file
    for(int h = 0; h < info_identifier.size(); h++)
    {
        fileOut<< info_identifier[h];
    }
    fileOut<<endl;

    //------------Create the BST---------------------------------------------------------------------------------------
    //for-loop 2: store every index of the vector with the line of information from the identifier in the string key
    for(int i = 0; i < info_identifier.size(); i++)
    {
        key = key + info_identifier[i];
    }
    
    //insert the string key in the BST
    n.update(key);
    key = "";// clear the string

    //clear vector and close file
    info_identifier.clear();
    fileOut.close();
}

/*---Funtion 2: emptyTxtFile---
Purpose: empty the output file in case it is not empty.
Parameters: 
    -String &filename = name of the file that we edit, it is declared in the main function.
    -char **argv = takes the second argument from the command line to print in the file .txt from wich .c file is the output. 
*/
void emptyTxtFile(string &filename, char **argv)
{
    ofstream fileOut(filename,ios::out | ios::trunc); 
    fileOut.close();

}

/*---Funtion 3: tokenizeFile2---
Purpose: tokenize the souce file, this is a second version of tokenizeFile for storing the file but in a different vector.
Parameters: 
    -String &line2 = string where the lines of the file are stored.
    -Vector <string> &data2 = where the new tokenized lines are stored temporary. 
    -Vector<string> &data3 = where the vector data3 is stored line by line to store the hole document.
*/
void tokenizeFile2(string &line2, vector<string> &data2, vector<string> &data3)
{
    line2.erase(remove(line2.begin(), line2.end(), '\t'),line2.end());
        
        //we tokenize the array by spaces
        string s = " ";
        while(line2.size())
        {
            int index = line2.find(s); //index in which exist our token
            if(index!=string::npos) //if index is found
            {
                data2.push_back(line2.substr(0,index)); //push-back from beggining until the index of the space
                line2 = line2.substr(index+s.size()); //substract all that has been pushed-back + token
                if(line2.size()==0)data2.push_back(line2);
            }
            else//index not found
            {
                data2.push_back(line2);
                line2 = "";
            } 
        }
    
        
        //store in a new vector each line of the vetor that stores the tokenize line
        for(int j = 0; j < data2.size(); j++)
        {
            data3.push_back(data2[j]);
        }
        
        data2.clear();
}

/*---Funtion 4: findTimesReferenced---
Purpose: find how many times an identifier name is referenced.
Parameters: 
    -String *buffer_func_name = the name of the function or the function name where the variable is.
    -String &identifier_func = string to declare whether or not an identifier is a function declaration or not.
    -String &identifier_name = name of the identifier.
    -String &referenced_str = string version of the counter for the referenced times (int referenced_count)
    -Char **argv = takes the second argument from the command line say which file we wan to open.

*/
void findTimesReferenced(string *buffer_func_name, string &identifier_func, string &identifier_name, string &referenced_str, char **argv)
{
    ifstream file2(argv[1]);
    string line2;
    vector<string> data2;
    vector<string> data3;
    vector<string> func_names_vec;//where we store all the function names
    int referenced_count = 0;//counter for the referenced identifiers
    const int key_size2 = 13; //sixe of the array keyWords2
    string keyWords2[key_size2] = {"int", "char", "short", "long" , "double", "float","int*", "char*", "short*", "long*" , "double*", "float*", "void"};//all the variable types and no-return-type (void)

    //While-loop: tokenize the source file again by spaces
    while(getline(file2,line2))
    {
        tokenizeFile2(line2,data2,data3);  
    }
    file2.close();


    
    //For-loop: create an array with all the functions names
    for(int i = 0; i < (key_size2); i++) //loop throught all the key words
    {
        for(int j = 0; j < data3.size(); j++)
        {   
            if(data3[j] == keyWords2[i]) 
            {        
                j++;
                j++;
                //if it is a function set the function store in the array its name
                if(data3[j] == "(")
                {
                    j--;
                    func_names_vec.push_back(data3[j]);
                    j++;
                }
                j--;
                j--;
            }
        }
    }

    //For-loop: find index where the identifier is first declared(so we discard everything that is before that identifier in the source file)
    int line_index = 0;
    for(int i = 0; i < data3.size(); i++)
    {
        if(data3[i] == *buffer_func_name)
        {
            line_index = i;
            break;
            
        }
    }

    //For-loop: We remove the function name were our identifier is from the array of function names
    //We do this because we will use the function array to find the end of our function scope (when the next function name appears)
    for(int i = 0; i < func_names_vec.size(); i++)
    {
        if(func_names_vec[i] == *buffer_func_name)
        {
            func_names_vec.erase(func_names_vec.begin() + i);
        }
    }
 

    /*This is the body of this function, here we find how many times the identifier is referenced in two statements:
      we will determine this identifier_func string in the storeLine function below.
    */
    int flag = 1;
    if(identifier_func == "not function")//CASE 1: not a function
    {   
        //loop in the array that stores the file from the index of the identifier when is declared
        //we also have our flag that will help us stop the loop when we exit the function scope.
        for(int j = line_index; j < data3.size() && flag == 1; j++)
        {
            if(data3[j] == identifier_name)
            {
                referenced_count++;
            
            }
            //for-loop to stop checking when we exit the function (this is when it is declared a new function with 
            //its variable type, its name that matches with one of the elements of the functions names array
            for(int i = 0; i < func_names_vec.size(); i++)
            {
                if(data3[j] == func_names_vec[i]) //we find a function name
                {
                    j--;
                    for(int g = 0; g < key_size2; g++)
                    {
                        if(data3[j] == keyWords2[g])//we find before it a variable type
                        {
                            flag = 0;//it is a function declaration, therefore we stop the first for-loop with our flag
                            break;
                        }
                    }
                    j++;
                } 
            } 
        }
    }
    else//CASE 2 : it is a function 
    {
        for(int j = 0; j < data3.size(); j++)
        {
            if(data3[j] == identifier_name)
            {
                referenced_count++;
            }
        }  
    }
    func_names_vec.push_back(*buffer_func_name);// we push back again in the arrayu of the function names the name of the function that we pop of before.
    
    referenced_count--; //one less fro the declarationd of identifier case

    //Convert int referenced to a string and push it to the vector(it will be pushed in the function storeLine below)
    stringstream ss;  
    ss << referenced_count;  
    ss >> referenced_str; 

}

/*---Funtion 5: storeLine---
Purpose: create the a row with all the identifier information.
Parameters: 
    -Vector<string> &info_identifier: where the raw of the identifier information is stored
    -Vector <string> &data = where the tokenized lines are stored.
    -Int &line_number: the line where the identifier is in the .c file.
    -Int &j = index of the data vector
    -String &var_type = where the variable type is temporary stored.
    -String *buffer_func_name = the name of the function or the function name where the variable is.
    -Int *p = pointer to the value of the flag of finding a funtion (int flag_function)
    -Char **argv = takes the second argument from the command line say which file we wan to open.

*/
void storeLine(vector<string> &info_identifier, vector<string> &data, int &line_number,int &j, string &var_type, string *buffer_func_name, int *p, char **argv)
{
    //Strings where the line number and the referenced counter will be stored
    string line_number_str; 
    string referenced_str;
    
    //get the name of the identifier and push it into the vectpr 
    string identifier_name = data[j];
    info_identifier.push_back(identifier_name);
  
   
    j++;
    
    //if the identifier is not a function and the function flag has been set to 1 (we are inside a function) push the function
    //name into the vector
    if(*p == 1 && data[j] != "(")
    {
        info_identifier.push_back(" (");
        info_identifier.push_back(*buffer_func_name);
        info_identifier.push_back(")");
    }
    
    //Convert int line_number to a string and push it to the vector
    stringstream s;  
    s << line_number;  
    s >> line_number_str;
    info_identifier.push_back(" , line ");
    info_identifier.push_back(line_number_str);
    
    string identifier_func = "not function";//string to declare whether or not an identifier is a function declaration or not
    //if statements to know where or not an identifier is a fuhnction, array or varible
    if(data[j] == "(")
    {
        info_identifier.push_back(", function,");
        identifier_func = "function";
        
    }
    else if(data[j] == "[]")
    {
        info_identifier.push_back(", variable,");
        identifier_func = "not function";
    }
    else
    {
        info_identifier.push_back(", variable, ");
        identifier_func = "not function";
        
    }

    //push into the vector the variable type
    info_identifier.push_back(var_type);
    
    //if the identifier is an array push in the vector the array symbol.
    if(data[j] == "[]")
    {
        info_identifier.push_back("[]");
    }
    j--;
    
    //Find how many times the identifier is referenced
    findTimesReferenced(buffer_func_name,identifier_func,identifier_name,referenced_str,argv);
    info_identifier.push_back(", referenced ");
    info_identifier.push_back(referenced_str);
    
}

/*---Funtion 6: tokenizeFile---
Purpose: tokenize the souce file by spaces.
Parameters: 
    -String &line = string where the lines of the file are stored.
    -Vector <string> &data = where the new tokenized lines are stored.

*/
void tokenizeFile(string &line, vector<string> &data)
{
    line.erase(remove(line.begin(), line.end(), '\t'),line.end());
        
        //we tokenize the array by spaces
        string s = " ";
        while(line.size())
        {
            int index = line.find(s); //index in which exist our token
            if(index!=string::npos) //if index is found
            {
                data.push_back(line.substr(0,index)); //push-back from beggining until the index of the space
                line = line.substr(index+s.size()); //substract all that has been pushed-back + token
                if(line.size()==0)data.push_back(line);
            }
            else//index not found
            {
                data.push_back(line);
                line = "";
            }
            
        }
}

/*---Funtion 7:  identifier_table_bst---
Purpose: main function of the .cpp file, here we find all the identifiers and call the necessary functions.
Parameters: 
    -Char **argv = takes the second argument from the command line say which file we wan to open.
*/
void identifier_table_bst(char **argv)
{
    const int key_size = 13;

    ifstream file(argv[1]); 
    string line;//buffer for the file lines
    

    int flag_function = 0; //flag when a function is found
    int line_number = 1; //the number of the line of the .c file, this will increment with each round in the wile-loop in line 386.
    
    string func_name;//string for the name of the functions
    string var_type; //string for the variable type
    string filename = "identifier.txt"; //file where the symbol_table will be printed.
    string keyWords[key_size] = {"int", "char", "short", "long" , "double", "float","int*", "char*", "short*", "long*" , "double*", "float*"}; //data types
    vector<string> data; //vector where the file lines are stored
    vector<string> info_identifier; //vector where the information about the identifiers is stored
    
    //declaration of the key to be inserted in the BST and create an object from the class BST
    string key;
    BST n;
    
    //function to empty the txt file in case that there is something writen on it.
    emptyTxtFile(filename,argv);

    while(getline(file,line)) //while the file is not NULL
    {
        // remove the tabs from the .c file.
        line.erase(remove(line.begin(), line.end(), '\t'),line.end());
        
        //tokenize the .c file by spaces adn insert the line in the data vector.
        tokenizeFile(line,data);

        int *p = &flag_function; //pointer to the flag_funtion address
        string *buffer_func_name = &func_name; //pointer to the func_name address

        //---------------------for-loop when a function does not return anything------------------------------------------
        for (int j = 0; j < data.size(); j++)
        {
            if(data[j] == "void") //when a void functions is found 
            {
                var_type = data[j]; //store the variable name
                j++;
                *buffer_func_name = data[j]; //store the function name
                storeLine(info_identifier,data,line_number,j, var_type,buffer_func_name,p,argv);
                writefile_buildBST(filename,info_identifier, key, n);
                
                j++;
                if(data[j] == "(")//if it is a function set the function flag to one
                {
                    *p = 1;
                }
            }
        }
        //---------------------for-loop for finding identifiers that are main functions and identifiers that are variables-----------
        
            for(int i = 0; i < (key_size - 1); i++) //loop throught all the key words but the null-pointer(that is why is: key_size - 1)
            {
                for(int j = 0; j < data.size(); j++) //loop through the vector size (where the .c line is stored)
                {
                    if(data[j] == keyWords[i])//if we find a matching
                    {     
                     
                        if(data[j] == "long" ) //CASE 1: found long word 
                        {
                            var_type = data[j];
                            j++;
                            if(data[j] == "long" || data[j] == "long*") // CASE 1.1: long long or long long* data types
                            {
                                var_type = var_type + " " + data[j];
                                j++;
                                
                                j++;
                                //if statement to determine if it is a function and set the flag function to 1, 
                                //that way we would store the function name and print it with all the variables that it has (this is done in the function storeLine called below),
                                //unless the function is a main function, where there is no need of printing its name with all its variables.
                                //We use this if structure in other statements below in this .cpp file.
                                //--------------------------------
                                if(data[j] == "(")
                                {
                                    j--;
                                    if(data[j] == "main")
                                    {
                                        *p = 0;
                                    }
                                    else
                                    {
                                        *p = 1;
                                    }
                                    
                                    *buffer_func_name = data[j];
                                }
                                //-------------------------------
                                j--;
                                
                                storeLine(info_identifier,data,line_number,j, var_type,buffer_func_name,p,argv);
                                writefile_buildBST(filename,info_identifier, key, n);
                                
                            }
                            else // CASE 1.2: just long data type (not long long nor long long*)
                            {
                                j++;
                                j++; 
                                 if(data[j] == "(")
                                {
                                    j--;
                                    if(data[j] == "main")
                                    {
                                        *p = 0;
                                    }
                                    else
                                    {
                                        *p = 1;
                                    }
                                    
                                    *buffer_func_name = data[j];
                                    
                                }
                                j--;
                                j--;
                                storeLine(info_identifier,data,line_number,j, var_type,buffer_func_name,p,argv);
                                writefile_buildBST(filename,info_identifier, key, n);
                                
                            }
                        }
                        else//CASE 2: all the other data types
                        { 
                            var_type = data[j];
                            j++;
                            j++;
                           
                            if(data[j] == "(")//check if it is a function 
                            {
                                
                                j--;
                                if(data[j] == "main")
                                {
                                    *p = 0;
                                }
                                else
                                {
                                    *p = 1;
                                }
                                *buffer_func_name = data[j];//get function name
            
                                storeLine(info_identifier,data,line_number,j, var_type,buffer_func_name,p,argv);
                                writefile_buildBST(filename,info_identifier, key, n);
                                
                            }
                            else
                            {
                                j--;
                                storeLine(info_identifier,data,line_number,j, var_type,buffer_func_name,p,argv);
                                writefile_buildBST(filename,info_identifier, key, n);
                                
                            }
                           
                            
                        }
                    }
                }
            }
        
        data.clear();
        line_number++;//next line
        
    }
    
    n.display(); //display the binary seach tree.
    file.close();
  
}