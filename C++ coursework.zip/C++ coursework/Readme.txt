Author: Sara Hussein Celda
Student ID: 40496531
Toolchain used: Microsoft Visual Studio 2019 Developer Command Prompt
Course: Software Engineering
Module: Programming Fundamentals, Year 1
Date: 30/04/2021
_____________________________________________________________________
Folder contents:
- all_programs_header.h
- bst.cpp
- bst.h
- findVarFunc.cpp
- identifier.txt
- identifier_table_bst.cpp
- ifStatementLoop.cpp
- Makefile
- symbol_table.cpp (it is the main .cpp file)
- Test files: test1.c test2.c test3.c test4.c
_____________________________________________________________________
How to compile and run:
1- Enter in the command prompt the following command to compile and link the application:
	nmake all

2- Enter in the command prompt line the name of the application name as specified below and the name of the .c file you 
    want to work with instead of <file_name.c> :
	symbol_table <file_name.c>

3-Once you are finished peering at the prompt, you can delete all the files created typing:
	nmake clean
	
Thank you for taking your time reading this file.
