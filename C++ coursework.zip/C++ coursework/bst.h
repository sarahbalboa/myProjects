/*
Author: Sara Hussein Celda
Date: 30/04/2021
Purpose: header that contains the BST class.
*/
#include <string>
using namespace std;
class BST
{
    private: 
        //struct node
        struct node;

        //root of the BST
        node* root;

        //function to destroy the BST
        node* destroyTree(node *root);
        //helper for the update method
        node* update_helper(string &key,  node **root);
    
        //order for the nodes of the bst
        void inorder(node *root);
    
    

    public:
        //constructor 
        BST();
        //destructor
        ~BST();
        //public update function
        void update(string &key);
        //public display functions
        void display();

};
