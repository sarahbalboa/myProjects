/*
Author: Sara Hussein Celda
Date: 30/04/2021
Purpose: code for the Binary Search Tree class, this BST program has methods to store in aplhabetic order the symbol_table and a method to print it. We have its constructor and destructor as well.
*/

#include <iostream>
#include <string>
#include <vector>
#include "bst.h"

using namespace std;


//struct node
struct BST::node {
    string data;
    node* left;
    node* right;
};

    

//function to destroy the BST
BST::node* BST::destroyTree(node *root) 
{
    if(root == NULL)
        return root;
    destroyTree(root->left);
    destroyTree(root->right);
    delete root;
    return NULL;
    
}

    
//helper for the update method in the bst, the data is inserted in alphabetic order
BST::node* BST::update_helper(string &key, node **root)
{
    if(*root == NULL) // of the root is NULL create a new node with the key and set the left and right branched to NULL
    {
        *root = new node;
        (*root)->data = key;
        (*root)->left = (*root)->right = NULL;
    }
    else//otherwise store the key in the correct branch only if it does not exist in the bsn.
    {
        if(key < (*root)->data)// the key comes alphabetic before the root 
            update_helper(key, &(*root)->left);
        if(key > (*root)->data)// the key comes alphabetic after the root 
            update_helper(key, &(*root)->right);
    }
    return *root;
    
}

//order for the nodes of the bst
void BST::inorder(node *root) 
{
    if(root == NULL)
        return;
    inorder(root->left);
    cout << root->data << "\n";
    inorder(root->right);
        
}

//constructor 
BST::BST() 
{
    root = NULL;
}

//destructor
BST::~BST() 
{
    destroyTree(root);
}

//method to update the bst
void BST::update(string &key) 
{
    update_helper(key, &root);
}

//method to display bst
void BST::display() 
{
    inorder(root);
    cout << endl;
}

 


