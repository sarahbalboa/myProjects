/*
Author: Sara Hussein Celda
Date: 30/04/2021
Purpose: initialize all the other programs that together they create an application called symbol_table. The purpose of each program is specified in its file.
*/
#include "all_programs_header.h"
#include <string>
#include <iostream>

//#include "bst.h"
using namespace std;


int main (int argc, char **argv)
{
    
    findVarFunct(argv); //call function to count how many identifiers are declared.
    ifStatementLoop(argv); // call function to count how many for-loops, while-loops and if-statements are in the .c file.

    cout<<endl;
    cout<<"Creating file with symbol_table...\nPrinting BST...\n "<<endl; // some sentences organize the printed information.

    identifier_table_bst(argv); //call funtion to create the .txt file and the binary search tree with the symbol_table.
    
    return 0;
}
