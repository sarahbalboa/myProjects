
select name,COUNT( payment_method_id) from 
payment_method join orders on (payment_method.id = orders.payment_method_id) 
group by name;


select first_name, last_name, COUNT(orders.id) as 'deliveries'
from rider 
	join users on rider.user_id=users.id
	join orders on rider.id=orders.rider_id
group by first_name, last_name
order by COUNT(orders.id) DESC
LIMIT 3;


select first_name, last_name, 
SUM(case when address.main = 1 then 1 else 0 end) as 'main',
SUM(case when address.main = 0 then 1 else 0 end) as 'other'
from users 
JOIN orders ON orders.customer_id = users.id
JOIN address ON address.id = orders.delivery_address_id
group by first_name,users.id, last_name
HAVING (SUM(case when address.main = 1 then 1 else 0 end) > 40) AND 
SUM(case when address.main = 0 then 1 else 0 end) > 0;


select order_id,
SUM(price * quantity) as 'items total'
,case 
	when (SUM(price * quantity) >= 0) AND (SUM(price * quantity) < 10) then CAST(3 as decimal(5,2))
	when (SUM(price * quantity) >= 10) AND (SUM(price * quantity) < 20) then CAST(2 as decimal(5,2))
	when (SUM(price * quantity) >= 20) AND (SUM(price * quantity) < 30) then CAST(1 as decimal(5,2))
	else CAST(0 as DECIMAL(5,2)) 
	END 'delivery',
(total_price - delivery_charge) as total, 
 delivery_charge as 'stored delivery charge',
total_price as 'stored total' 
from order_item 
	join orders on order_item.order_id=orders.id
	join food_item on order_item.food_item_id=food_item.id 
group by order_id, total_price, delivery_charge
HAVING (case 
	when (SUM(price * quantity) >= 0) AND (SUM(price * quantity) < 10) then CAST(3 as decimal(5,2))
	when (SUM(price * quantity) >= 10) AND (SUM(price * quantity) < 20) then CAST(2 as decimal(5,2))
	when (SUM(price * quantity) >= 20) AND (SUM(price * quantity) < 30) then CAST(1 as decimal(5,2))
	else CAST(0 as DECIMAL(5,2)) 
	END) != delivery_charge;


select post_code, first_name ,last_name, count(orders.id) as 'orders',
ROUND((SUM(total_price)/(select COUNT(DISTINCT(cast(order_date as date))) 
from orders join users as u2 on orders.customer_id=u2.id where u1.id=u2.id )), 2) 
as 'average daily spend'
from address 
join orders on address.user_id=orders.customer_id
join users as u1 on address.user_id=u1.id 
group by post_code, first_name,last_name, 'orders', 'total', u1.id 
HAVING post_code = (select post_code
from address join orders on address.user_id=orders.customer_id
group by post_code
HAVING (count(orders.id)) = (select MAX(a.orders) as 'maximum' from 
(select post_code, count(orders.id) as orders
from address join orders on address.user_id=orders.customer_id
group by post_code) a));
