    CREATE TABLE rate_review(
	rate_id INT(11) AUTO_INCREMENT PRIMARY KEY,
	rider_id INT(11) REFERENCES rider(id),
  customer_id VARCHAR(5) REFERENCES cust(id),
  order_id INT(11) UNIQUE REFERENCES orders(id) ,
  restaurant_name VARCHAR(50) REFERENCES restaurant(name),
  date_rate date NOT NULL,
  food_quality  DECIMAL(5,1) 
    CHECK (food_quality BETWEEN 0.0 AND 5.0),
  delivery  DECIMAL(5,1)
    CHECK (delivery BETWEEN 0.0 AND 5.0),
  overall_satisfaction 	DECIMAL(5,1)
    CHECK (overall_satisfaction BETWEEN 0.0 AND 5.0),
	rev_food VARCHAR(50),
	rev_delivery VARCHAR(50),
	rev_ov_satisfaction VARCHAR(50),
	CONSTRAINT const_rev_food
	  CHECK(((food_quality IS NOT NULL) AND (rev_food IS NOT NULL)) XOR ((food_quality IS NULL) 
	  AND (rev_food IS NULL)) XOR 
	  ((food_quality IS NOT NULL) AND (rev_food IS NULL))),
	CONSTRAINT const_rev_delivery
	  CHECK(((delivery IS NOT NULL) AND (rev_delivery IS NOT NULL)) XOR ((delivery IS NULL) 
	  AND (rev_delivery IS NULL)) XOR 
	  ((delivery IS NOT NULL) AND (rev_delivery IS NULL))),
	CONSTRAINT const_rev_satisfaction
	  CHECK(((overall_satisfaction IS NOT NULL) AND (rev_ov_satisfaction IS NOT NULL)) XOR 
	  ((overall_satisfaction IS NULL) AND (rev_ov_satisfaction IS NULL)) XOR 
	  ((overall_satisfaction IS NOT NULL) AND (rev_ov_satisfaction IS NULL)))
  );
  
  
    INSERT INTO cust(id, name, addr)
VALUES
('1','Harrow','34 Ninth House'),
('2','Gideon','12 Ninth House'),
('3','Palamedes','5 Sixth House'),
('4','Camilla','78 Sixth House'),
('5','Magnus','9 Fifth House'),
('6','Abigail','10 Fifth House'),
('7','Coronabeth','11 Third House'),
('8','Ianthe','24 Third House'),
('9','Isaac','56 Fourth House'),
('10','Jeannemary','6 Fourth House');

  
INSERT INTO rate_review(customer_id,rider_id,order_id,restaurant_name,date_rate,food_quality,
delivery,overall_satisfaction,rev_food,rev_delivery, rev_ov_satisfaction)
VALUES
('3',2,2,'Verdo','2021-06-07',4.3,3.3,1.2,'good','medium','bad'),
('7',3,4,'Verdo','2021-06-13',1.3,3.2,4.2,'good','medium',''),
('9',4,5,'Verdo','2021-06-17',4.5,3.2,1.2,'bad','medium','bad'),
('10',4,6,'Verdo','2021-06-19',4.5,3.0,1.2,'good','medium','bad'),
('8',5,7,'Verdo','2021-06-23',2.4,1.4,4.4,'good','medium','bad'),
('6',2,8,'Verdo','2021-07-02',2.5,2.0,4.4,'good','medium','bad'),
('2',1,10,'Verdo','2021-07-08',1.5,3.3,4.5,'medium','medium','bad');


INSERT INTO rate_review(customer_id,rider_id,order_id,restaurant_name,date_rate,food_quality)
VALUES
('1',3,1,'Verdo','2021-06-03',4.6);

INSERT INTO rate_review(customer_id,rider_id,order_id,restaurant_name,date_rate,food_quality,overall_satisfaction,rev_food, rev_ov_satisfaction)
VALUES
('5',4,3,'Verdo','2021-06-11',3.7,3,'good','bad');

INSERT INTO rate_review(customer_id,rider_id,order_id,restaurant_name,date_rate,food_quality,rev_food)
VALUES
('4',1,9,'Verdo','2021-07-04',3.1,'good');


