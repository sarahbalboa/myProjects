  select restaurant_name , ROUND((SUM(food_quality)/COUNT(food_quality)),1) AS 'average_food',
  ROUND((SUM(delivery)/COUNT(delivery)),1) AS 'average_delivery', 
  ROUND((SUM(overall_satisfaction)/COUNT(overall_satisfaction)),1) AS 'average_satisfac'
  FROM (select restaurant_name,food_quality,delivery,overall_satisfaction, date_rate from rate_review c
  where date_rate >= (select (select max(b.date_rate) AS Latest from 
  rate_review b
  where b.restaurant_name=a.restaurant_name
  group by b.restaurant_name) - INTERVAL +28 DAY as '-4 weeks' from rate_review a where a.restaurant_name=c.restaurant_name
  group by restaurant_name)
  group by restaurant_name, date_rate, food_quality, delivery, overall_satisfaction) second_table 
  group by restaurant_name;
 
 select rider_id,ROUND((SUM(delivery)/COUNT(delivery)),1) AS 'average_delivery'
  FROM (select rider_id,delivery, date_rate from rate_review c
  where date_rate >= (select (select max(b.date_rate) AS Latest from 
  rate_review b
  where b.rider_id=a.rider_id
  group by b.rider_id) - INTERVAL +10 DAY as '-10 DAYS' from rate_review a where a.rider_id=c.rider_id
  group by rider_id)
  group by rider_id, date_rate,delivery) second_table 
  group by rider_id;
  