

{-
READ ME: Change the name of this file to YOURSTUDENTNUMBER.hs. For example, if your
student number were 123456789, then you would rename the file 123456789.hs.

REPLACE the function definitions for each of the questions. 
The names of the functions correspond to the names given in the document cwk21handout.pdf. 

DO NOT CHANGE THE TYPE SIGNATURES, OR THE ORDER OF THE ARGUMENTS!

You may add as many extra or helper functions as you wish, but do not make any "import" statements.

:load C:\Users\sarah\Documents\MathsHaskell\40496531.hs
-}
{-----------------------------------------------EXTRA Functions-------------------------------------------------}
{-------------QUESTION 1-------------}
maximum' :: (Ord a) => [a] -> a  
maximum' [] = error "maximum of empty list"  
maximum' [x] = x  
maximum' (x:xs) = max x (maximum' xs)

findI' :: (Eq a) => a -> [a] -> Int
findI' x [] = error "Not found"
findI' x (y:ys)
        | x == y = 2
        | otherwise = 1 + findI' x ys

findI :: (Eq a) => a -> [a] -> Maybe Int
findI x ys
        | elem x ys = Just (findI' x ys)
        | otherwise = Nothing

duplicateFree :: (Eq a) => [a] -> [a]
duplicateFree [] = []
duplicateFree (x:xs)
        | elem x xs = duplicateFree xs
        | otherwise = x : duplicateFree xs

{-------------QUESTION 2-------------}
myCommutative2 :: [((Int,Int),Int)] -> [((Int,Int),Int)]
myCommutative2 xs = map flipIt2 xs
        where flipIt2 ((x,y),c) = ((y,x),c)

myCommutative3 :: [((Int,Int),Int)] -> [((Int,Int),Int)]
myCommutative3 xs = map flipIt3 xs ++ map flipIt4 xs
        where flipIt3 ((x,y),c) = ((x,x),x)
              flipIt4 ((x,y),c) = ((y,y),y)

fPath' :: (Eq a) => [a] -> [(a,a)] -> [[a]]
fPath' pss [] = []
fPath' (p:ps) (x:xs)
        | last (p:ps) == fst x = (insertList (chunkList (p:ps) x) []) ++ fPath' (p:ps) xs
        | otherwise = fPath' (p:ps) xs

chunkList :: [a] -> (a,a) -> [a]
chunkList (p:ps) (x,y) = addAtEnd y (p:ps)

insertList :: [a] -> [a] -> [[a]]
insertList xss [] = [xss]
{-------------QUESTION 3-------------}
factors :: Int -> [Int] -- type signature
factors n = [x | x <- [1..n], n `mod` x == 0]

prime :: Int -> Bool
prime n = factors n == [1,n]

primes :: Int -> [Int]
primes n = [x | x <- [0..n], prime x]

primes2 :: Int -> [Int]
primes2 n 
        | n <= 99 = filter prime(take 30(myReverse[1,3..(n-1)]))
        | n <= 9999  && n > 99 = filter prime(take 30(myReverse[101,103..(n-1)]))
        | n <= 99999 && n > 9999 = filter prime(take 30(myReverse[10001,10003..(n-1)]))
        | n <= 999999 && n > 99999 = filter prime(take 100(myReverse[100001,100003..(n-1)]))
        | otherwise = error "Input not valid (enter an integer less than 9999999)"


addAtEnd :: a -> [a] -> [a]
addAtEnd x [] = [x]
addAtEnd x (y:ys) = y : addAtEnd x ys 

myReverse :: [a] -> [a]
myReverse [] = []
myReverse (x:xs) = addAtEnd x (myReverse xs)

divides :: Int -> Int -> Bool
divides m n = rem m n == 0

divides' :: Int -> Int -> Bool
divides' m n = rem n m == 0

isComposite :: Int -> Bool
isComposite n = foldl (||) False (map (divides n) [2..(n-1)])

isPrime :: Int -> Bool
isPrime n
        | n <=0 = error "Makes no sense"
        | otherwise = not (isComposite n)

isFactorOf :: Integral a => a -> a -> Bool
isFactorOf x n = n `mod` x == 0

createList n f | f <= n `div` 2 = if f `isFactorOf` n
                                     then f : next
                                     else next
               | otherwise      = []
    where next = createList n (f + 1)

factorList' :: Int -> [Int]
factorList' n 
        | n == 2 = [ x | x <- [1], x `isFactorOf` n, prime x]
        | otherwise = [ x | x <- [1,3..(n-1)], x `isFactorOf` n, prime x] ++ [ x | x <- [2], x `isFactorOf` n]

mySafeFactor :: Int -> Maybe [Int]
mySafeFactor n 
        | factorList' n == [] = Nothing
        | otherwise = Just (factorList' n)

{---------------------QUESTION 4----------------------}
upToList :: Int -> [Int]
upToList n = [0..(n-1)]

coprime a b = gcd a b == 1

coprime2 :: Int -> [Int] -> [Int]
coprime2 n [] = []
coprime2 n (x:xs)
        | coprime n x == True = x : coprime2 n xs
        | otherwise = coprime2 n xs


{------------------------------------------------END OF EXTRA FUNCTIONS------------------------------------------------------------}



{- QUESTION 1: Sets -}

bigUnion :: (Eq a) => [[a]] -> [a]
bigUnion ([]:xss) = bigUnion xss
bigUnion ((x:xs):[]) = (x:xs)
bigUnion ((x:xs):xss) = duplicateFree(x : (bigUnion (xs:xss)))

partialSums :: [Int] -> [Int]
partialSums [] = []
partialSums (x:xs) = x : map (+ x)(partialSums xs)


maxIndex :: [Int] -> Maybe Int
maxIndex [x] = Just 1
maxIndex [] = Nothing
maxIndex (x:xs) = findI biggest transformed 
    where 
        transformed = partialSums xs
        biggest = maximum' (transformed)


-- TEST SET FOR Q1
{-
Your functions should have the following behaviour:

bigUnion [[1,2,3],[3,4,5],[2,4,6,8]] = [1,2,3,4,5,6,8]
bigUnion ["list a", "list b"] = "list ab"
 
THE ORDER OF ELEMENTS IN THE RESULTS bigUnion IS NOT IMPORTANT.

partialSums [1,2,3,4,5] = [1,3,6,10,15]
partialSums [-1,1,-1,1,-1] = [-1,0,-1,0,-1]

maxIndex [1,2,3,4,5] = Just 5
maxIndex [-1,1,-1,1,-1] = Just 2

-}



-- QUESTION 2: Functions and relations

makeCommutative :: [((Int,Int),Int)] -> [((Int,Int),Int)]
makeCommutative xss = duplicateFree (xss ++ myCommutative3 xss ++ myCommutative2 xss)

oneHop :: (Eq a) => a -> [(a,a)] -> [a]
oneHop y [] = []
oneHop y (x:xs)
        | y == fst x = snd x : oneHop y xs 
        | otherwise = oneHop y xs

nextSteps :: (Eq a) => [a] -> [(a,a)] -> [[a]]
nextSteps (p:ps) (x:xs) = fPath' (p:ps) (x:xs)


allElementsReachable :: (Eq a) => Int -> a -> [(a,a)] -> [a]
allElementsReachable n x rs = error "You've not tried to write allElementsReachable yet"

-- TEST SET FOR Q2
{-
Your functions should have the following behaviour:

makeCommutative [((1,2),3),((3,2),5),((1,4),0)] = 
    [((2,1),3),((2,3),5),((4,1),0),((1,2),3),((3,2),5),((1,4),0),((3,3),3),((1,1),1),((2,2),2),((4,4),4)]
    
makeCommutative [((4,1),0)] =
    [((1,4),0),((4,1),0),((4,4),4),((1,1),1)]

oneHop 3 [(1,3),(3,2),(3,4),(3,1),(2,3),(1,4)] = [2,4,1]
oneHop 1 [(1,3),(3,2),(3,4),(3,1),(2,3),(1,4)] = [3,4]

DO NOT WORRY ABOUT THE ORDER OF THE ELEMENTS IN THE RETURN LIST FOR oneHop

nextSteps [1,3] [(1,3),(3,2),(3,4),(3,1),(2,3),(1,4)] = [[1,3,2],[1,3,4],[1,3,1]]
nextSteps [3,4] [(1,3),(3,2),(3,4),(3,1),(2,3),(1,4)] = []

DO NOT WORRY ABOUT THE ORDER OF THE ELEMENTS IN THE RETURN LIST (i.e. THE ORDER THE LISTS APPEAR IN THE LIST OF LISTS)

allElementsReachable 2 1 [(1,3),(3,2),(3,4),(3,1),(2,3),(1,4)] = [2,4,1]
allElementsReachable 6 4 [(1,3),(3,2),(3,4),(3,1),(2,3),(1,4)] = []

DO NOT WORRY ABOUT THE ORDER OF THE ELEMENTS IN THE RETURN LIST FOR allElementsReachable

-}



-- QUESTION 3: Primes
 
lastPrimes :: Int -> [Int]
lastPrimes n 
        | n <= 999999 = take 3(primes2 n)
        | otherwise = error "You've not tried to write lastPrimes for big numbers yet"
     


primeFactors :: Int -> Maybe [Int]
primeFactors n
    | n <= 9999999 = mySafeFactor n
    | otherwise = error "You've not tried to write primeFactors for big numbers yet"

{- 
Leave the error messages in place if you do not want to attempt the parts for the input size. You should remove the guards up to the point you want to attempt. For example, if you were confident of anything up to five digits, the function would look like:

primeFactors n
    | n <= 99999 = whatever_your_calculation_is
    | n <= 999999 = error "..."
    | otherwise = error "..."

 -}




-- TEST SET FOR Q3
{-
Your functions should have the following behaviour:

lastPrimes 73 = [71,67,61]
lastPrimes 64 = [61,59,53]

DO NOT WORRY ABOUT THE ORDER OF THE LIST FOR lastPrimes

primeFactors 75 = Just [3,5]
primeFactors 64 = Just [2]
primeFactors 61 = Nothing

DO NOT WORRY ABOUT THE ORDER OF THE LIST FOR primeFactors
-}




-- QUESTION 4: RSA

eTotient :: Int -> Int
eTotient n =  length(coprime2 n (upToList n))

encode :: Int -> Int -> Int -> Int -> Maybe Int
encode p q m e = error "You've not tried to write encode yet"

-- TEST SET FOR Q4
{-
Your functions should have the following behaviour:
eTotient 54 = 18
eTotient 73 = 72
encode 37 23 29 5 = Just 347
encode 99 18 108 45 = Nothing
encode 37 17 23 48 = Nothing
-}


